import type { FastifyInstance } from "fastify";
import { env } from "../config/env.ts"; // [cite: 53]
import { getDb } from "../db/sqlite.ts";
import { scrubText } from "../utils/piiScrubber.ts"; // [cite: 38]
import { createMessage, listRecentMessages, updateMessageContent } from "../models/messageRepo.ts";
import { generateReply } from "../ai/aiClient.ts";
import { getMessageById } from "../models/messageRepo.ts";

export const chatRoutes = async (app: FastifyInstance): Promise<void> => {
  // Config values from environment variables
  const ttlDays = (env as any).messageTtlDays ?? 14; // Default to 14 days as per plan [cite: 32]
  const ctxLimit = (env as any).messageContextLimit ?? 20; // Default limit for history context

  app.post(
    "/chat/message",
    {
      schema: {
        body: {
          type: "object",
          additionalProperties: false,
          required: ["message"],
          properties: {
            message: { type: "string", minLength: 1, maxLength: 20000 },
            conversationId: { type: "string", minLength: 1, maxLength: 120 },
          },
        },
      },
    },
    async (req, reply) => {
      const userId = req.currentUserId;
      if (!userId) return reply.status(401).send({ error: "unauthorized" });

      const body = req.body as { message: string; conversationId?: string };
      const conversationId = body.conversationId ?? "default";

      const db = await getDb();

      // Ensure PII scrubbing happens before storage 
      const scrubbedUserMsg = scrubText(body.message);

      await createMessage(db, {
        userId,
        conversationId,
        role: "user",
        content: scrubbedUserMsg,
        ttlDays: ttlDays,
      });

      const placeholder = await createMessage(db, {
        userId,
        conversationId,
        role: "assistant",
        content: "processing",
        ttlDays: ttlDays,
      });

      void (async () => {
        try {
          // Use configurable context limit instead of hardcoded 20
          const recent = await listRecentMessages(db, userId, conversationId, ctxLimit);
          const context = recent
            .reverse()
            .map((m) => ({ role: m.role, content: m.content }));

          const out = await generateReply({
            requestId: placeholder.id,
            scrubbedMessage: scrubbedUserMsg,
            context,
          });

          const scrubbedReply = scrubText(out.scrubbedReply);
          await updateMessageContent(db, placeholder.id, scrubbedReply, ttlDays);
        } catch {
          await updateMessageContent(db, placeholder.id, "error_generating_reply", ttlDays);
        }
      })();

      return {
        assistantMessageId: placeholder.id,
        conversationId,
        status: "queued",
      };
    },
  );

  app.get(
    "/chat/history",
    {
      schema: {
        querystring: {
          type: "object",
          additionalProperties: false,
          properties: {
            conversationId: { type: "string", minLength: 1, maxLength: 120 },
            limit: { type: "string", pattern: "^[0-9]+$" },
          },
        },
      },
    },
    async (req, reply) => {
      const userId = req.currentUserId;
      if (!userId) return reply.status(401).send({ error: "unauthorized" });

      const q = (req.query ?? {}) as Record<string, any>;
      const conversationId = q.conversationId ?? "default";
      const n = q.limit ? Number(q.limit) : 50;
      const limit = Number.isFinite(n) ? Math.min(Math.max(n, 1), 200) : 50;

      const db = await getDb();
      const rows = await listRecentMessages(db, userId, conversationId, limit);

      return rows.reverse().map((m) => ({
        id: m.id,
        role: m.role,
        content: m.content,
        createdAt: m.createdAt,
      }));
    },
  );
    app.get(
    "/chat/message/:id",
    {
      schema: {
        params: {
          type: "object",
          additionalProperties: false,
          required: ["id"],
          properties: {
            id: { type: "string", minLength: 1, maxLength: 120 },
          },
        },
      },
    },
    async (req, reply) => {
      const userId = req.currentUserId;
      if (!userId) return reply.status(401).send({ error: "unauthorized" });

      const p = req.params as { id: string };
      const db = await getDb();

      const row = await getMessageById(db, userId, p.id);
      if (!row) return reply.status(404).send({ error: "not_found" });

      return {
        id: row.id,
        role: row.role,
        content: row.content,
        createdAt: row.createdAt,
      };
    },
  );
};